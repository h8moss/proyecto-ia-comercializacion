using System;
using UnityEngine;

public class Interactable : MonoBehaviour
{
    public Action onInteraction;
}
